-- Create database
CREATE DATABASE IF NOT EXISTS AttendanceDB;
USE AttendanceDB;

-- Optional: Create Students table
CREATE TABLE IF NOT EXISTS Students (
    StudentID VARCHAR(20) PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Class VARCHAR(20)
);

-- Create Attendance table
CREATE TABLE IF NOT EXISTS Attendance (
    AttendanceID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID VARCHAR(20) NOT NULL,
    Date DATE NOT NULL,
    Status VARCHAR(10) NOT NULL,
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID)
);

-- Insert sample students (optional)
INSERT INTO Students (StudentID, Name, Class) VALUES 
('S101', 'Prashu Singh', 'CSE-2nd'),
('S102', 'Aarav Kumar', 'CSE-2nd'),
('S103', 'Riya Sharma', 'CSE-2nd');
