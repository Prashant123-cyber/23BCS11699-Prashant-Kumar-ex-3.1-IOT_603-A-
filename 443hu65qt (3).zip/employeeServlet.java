import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/employeeServlet")
public class employeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/CompanyDB";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Employee Records</title></head><body>");
        out.println("<h2>Employee Records</h2>");

        // Search form
        out.println("<form method='get' action='employeeServlet'>");
        out.println("Search by Employee ID: <input type='text' name='empId'>");
        out.println("<input type='submit' value='Search'>");
        out.println("</form><br>");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String empId = request.getParameter("empId");
            if (empId != null && !empId.trim().isEmpty()) {
                // Fetch single employee by ID
                String sql = "SELECT * FROM Employee WHERE EmpID = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, Integer.parseInt(empId));
            } else {
                // Fetch all employees
                String sql = "SELECT * FROM Employee";
                pstmt = conn.prepareStatement(sql);
            }

            rs = pstmt.executeQuery();

            // Display results in HTML table
            out.println("<table border='1' cellpadding='10'>");
            out.println("<tr><th>EmpID</th><th>Name</th><th>Salary</th></tr>");

            boolean hasRecords = false;
            while (rs.next()) {
                hasRecords = true;
                int id = rs.getInt("EmpID");
                String name = rs.getString("Name");
                double salary = rs.getDouble("Salary");
                out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + salary + "</td></tr>");
            }

            if (!hasRecords) {
                out.println("<tr><td colspan='3'>No records found</td></tr>");
            }

            out.println("</table>");
        } catch (ClassNotFoundException e) {
            out.println("JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            out.println("Database error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                out.println("Error closing resources: " + e.getMessage());
            }
        }

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Forward POST request to doGet
        doGet(request, response);
    }
}
