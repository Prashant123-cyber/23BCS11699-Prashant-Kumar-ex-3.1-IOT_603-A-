-- Create database
CREATE DATABASE IF NOT EXISTS CompanyDB;
USE CompanyDB;

-- Create Users table for login
CREATE TABLE IF NOT EXISTS Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(50) NOT NULL
);

-- Insert sample users
INSERT INTO Users (Username, Password) VALUES
('prashu', '12345'),
('aarav', 'password'),
('riya', 'pass123');

-- Create Employee table
CREATE TABLE IF NOT EXISTS Employee (
    EmpID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    Salary DECIMAL(10,2) NOT NULL
);

-- Insert sample employee records
INSERT INTO Employee (Name, Salary) VALUES
('John Doe', 50000.00),
('Jane Smith', 60000.00),
('Robert Brown', 55000.00);
